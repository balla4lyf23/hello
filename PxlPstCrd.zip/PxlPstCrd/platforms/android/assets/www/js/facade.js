function addPost() {

    //instructs program as to what should be dipalyed in teh console (whether validation succeeds or fails)
    if (doValidation_frmAddPost()) {
        console.info("Validation is successful");
        var post = $("#TAPost").val();
        var options = [post];
        post.insert(options);
    }
    else {
        console.error("Validation fails");
    }
}
function showAllPost() {
    function successSelectAll(tx, results) {
        var htmlCode = "";

        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows[i];
            console.info("id: " + row['id'] + " post: " + row['post']);

            htmlCode += "<li><a data-role='button' data-row-id=" + row['id'] + " href='#'>"
        }

        var lv = $("#lvPost");
        lv = lv.html(htmlCode);
        lv.listview("refresh");
        $("#lvPost a").on("click", clickHandler);
        function clickHandler() {
            localStorage.setItem("id", $(this).attr("data-row-id"));
            //navigation
        }

    }

    post.selectAll(successSelectAll);
}