var db;

function errorHandler(tx, error) {
    console.error("SQL error: " + tx + " (" + error.code + ") -- " + error.message);
}

function successTransaction() {
    console.info("Success: Transaction is successful");
}

//this code creates the database
var DB = {
    createDatabase: function () {
        var shortName = "PxlPstDB";
        var version = "1.0";
        var displayName = "DB for PxlPst";
        var dbSize = 2 * 1024 * 1024;

        console.info("Creating database ...");


        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);

        function dbCreateSuccess() {
            console.info("Success: Database creation successful.");
        }
    },

    //this code creates the table that we will be needing
    createTables: function () {
        function txFunction(tx) {
            var sql = "CREATE TABLE IF NOT EXISTS post(" +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "TAPost VARCHAR(140) NOT NULL";

            var options = [];

            function successCreate() {
                console.info("Success: Table creation successful");
            }

            tx.executeSql(sql, options, successCreate, errorHandler);
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};
