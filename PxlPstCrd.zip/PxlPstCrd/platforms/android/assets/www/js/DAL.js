var post = {
    insert: function (options) {
        function txFunction(tx) {
            var sql = "INSERT INTO post(TAPost) " +
                "values(?);";
            // var options = [];

            function successInsert() {
                console.info("Success: Insert successful");
                alert("New record added");
            }

            tx.executeSql(sql, options, successInsert, errorHandler);
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    selectAll: function (successSelectAll) {
        function txFunction(tx) {
            var sql = "SELECT * FROM friend;";
            var options = [];

            tx.executeSql(sql, options, successSelectAll, errorHandler);
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    select: function (options, successSelectOne) {
        function txFunction(tx) {
            var sql = "SELECT * FROM post WHERE id=?;";
            tx.executeSql(sql, options, successSelectOne, errorHandler);
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};