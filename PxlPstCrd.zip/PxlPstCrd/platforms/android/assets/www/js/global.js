
//the click event for the button that adds a post
    function btnAdd_click() {
    if (doValidation_frmAddPost()) {
        console.info("Validation is successful");
    }
    else {
        console.error("Validation fails");
    }

}

//gets the database ready to be used
function initDB() {
    console.info("Creating Database.");
    try {
        DB.createDatabase();
        if (db) {
            console.info("Creating Tables!");
            DB.createTables();
        }
        else {
            console.error("Error: Cannot create tables : Database not available!");
        }
    } catch (e) {
        console.error("Fatal: Error in initDB(). Can not proceed.");
    }
}

function pageHome_show() {
    showAllPost();
}

//initializing button clicks and makes pages display to user
function init () {

    $("#btnAdd").on("click", btnAdd_click);
    $("#pageHome").on("pageshow", pageHome_show);
    
}

$(document).ready(function () {
    initDB();
    init();
});
