//this function runs validation on the text field that is used for adding a post
function doValidation_frmAddPost() {
    var form = $("#frmAddPost");
    form.validate({
        rules: {
            TAPost: {
                required: true,
                minlength: 4
            }

        },
        messages: {
            TAPost: {
                required: "Post must not be empty",
                minlength: "Your post must be at least 4 characters long"
            }
        }
    });
    return form.valid();
}